"use strict";
/**
 * 北极星项目 · 统一服务入口 —— 一个进程、一个端口，同时提供全部端点
 *
 *   POST /api/v1/collect/:webhook_id   （单元 1.2，collect/server.ts 原实现）
 *   GET  /api/analytics/events         （单元 1.4，events/query.ts 原实现）
 *   GET  /api/analytics/funnel         （单元 2.4，ads/funnel.ts 原实现）
 *   GET  /api/analytics/audit/token    （单元 1.5，audit/route.ts 原实现）
 *
 * ── 方案选择（实测依据）────────────────────────────────────────────────────
 * 方案 A（Fastify 插件挂载「实例」）不可行：buildQueryServer / buildFunnelServer /
 * buildServer / buildTokenAuditServer 返回的是 Fastify **实例**，不是插件函数。
 * 实测 `parent.register(childInstance)` 同步不抛错、但 `ready()` 阶段 avvio 抛
 * `TypeError: func is not a function`（见 report / .tmp-plan-a-test.cjs）。因此
 * 采用方案 B：复用各模块已导出的纯函数，在统一 app 上按「与各单元逐字一致」的
 * 鉴权顺序与错误码重新注册路由。
 *
 * 复用点（不重写业务逻辑）：
 *   - audit：直接 `app.register(tokenAuditRoutes, opts)`（audit/route.ts 已导出插件）。
 *   - events：parseAuthorization / parseEventFilters / queryEventsScoped / serializeEventRow。
 *   - funnel：parseAuthorization / parseFunnelParams / queryFunnelScoped /
 *             serializeFunnelGroup / serializeRoiEntity + DEFAULT_SOURCE_PLATFORM_RULES。
 *   - collect：validateEvent / tryExtractEventId / secretMatches（secretMatches 由
 *             collect/server.ts 导出，此处直接 require 复用，不重复实现）。
 *
 * 铁律（不得因「合并」而放松任何一道）：
 *   1. 只读：三个分析端点纯 GET，无 body、无写操作；collect 只「接收 + 鉴权 + 入队」。
 *   2. tenant 只从 token（分析端点）/ Secret 反查（collect）派生，绝不读 query / body。
 *   3. 鉴权顺序与错误码逐字对齐：缺失/非法/过期 token → 401；可识别但非只读 token
 *      （读写 key / webhook Secret / 未知）→ 403；scope 不含 analytics:read → 403；
 *      参数非法 → 400；依赖查询/入队出错 → 500 / 503。
 *   4. 依赖（pool / verifyAnalyticsToken / loadAuditLogs / loadConfigFindings /
 *      resolveEndpoint / enqueue / resolveWorkspaceId）全部参数注入，不硬编码连接。
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildUnifiedServer = buildUnifiedServer;
exports.startUnifiedServer = startUnifiedServer;
const fastify_1 = __importDefault(require("fastify"));
const collect_server_1 = require("./collect/server");
const validate_1 = require("./collect/validate");
const validate_2 = require("./collect/validate");
const query_1 = require("./events/query");
const funnel_1 = require("./ads/funnel");
const attribution_1 = require("./ads/attribution");
const route_1 = require("./audit/route");
const import_1 = require("../../business/attribution/import/routes");
const event_import_1 = require("../../business/attribution/import/event-routes");
const ingestion_1 = require("../../business/attribution/ingestion-adapter/routes");
const ingestion_service_1 = require("../../business/attribution/ingestion-adapter/service");
const raw_ingest_1 = require("../../business/attribution/ingestion-adapter/raw-ingest-routes");
const attribution_api_1 = require("../../business/attribution/api/routes");
// ---- P1 #6：可信租户头注入（默认关；TRUST_TENANT_HEADER=1 且 X-Tenant-Id 为合法 UUID 时生效）----
// 信任边界：本服务只应由业务壳（同机 127.0.0.1）反代访问；业务壳只透传「其登录会话派生」
// 的租户。此处是「可信头 → 租户」的唯一收口，供 A 方案每租户隔离（set_config + RLS 已就绪）。
// 默认关闭时完全不读该头，与旧行为一致（租户只从 token 派生，B 方案共享演示数据兜底）。
const TRUST_TENANT_HEADER = process.env.TRUST_TENANT_HEADER === "1";
function trustedTenantHeader(request) {
    if (!TRUST_TENANT_HEADER)
        return null;
    const h = request && request.headers ? request.headers["x-tenant-id"] : undefined;
    const v = Array.isArray(h) ? h[0] : h;
    if (typeof v !== "string" || v.length === 0)
        return null;
    return (0, validate_1.isUuid)(v) ? v : null;
}
function errorBody(code, message, eventId) {
    return eventId === undefined
        ? { ok: false, error: { code, message } }
        : { ok: false, error: { code, message }, event_id: eventId };
}
function toError(err) {
    return err instanceof Error
        ? err
        : new Error(typeof err === "string" ? err : "unknown error");
}
/** 三个分析端点共用的兜底错误码（照抄 events/query.ts / ads/funnel.ts / audit/route.ts）。 */
function analyticsErrorBody(statusCode) {
    return errorBody(statusCode >= 500 ? "INTERNAL_ERROR" : "BAD_REQUEST", statusCode >= 500 ? "internal error" : "bad request");
}
// ---------------------------------------------------------------------------
// collect：Secret 比对复用 collect/server.ts 原实现（exports.secretMatches）
// ---------------------------------------------------------------------------
/** Fastify 框架错误码 → 业务错误码（collect/server.ts §4.1 原表）。 */
const FST_ERROR_CODE = {
    FST_ERR_CTP_BODY_TOO_LARGE: "PAYLOAD_TOO_LARGE",
    FST_ERR_CTP_INVALID_JSON_BODY: "INVALID_JSON",
    FST_ERR_CTP_EMPTY_JSON_BODY: "INVALID_JSON",
    FST_ERR_CTP_INVALID_MEDIA_TYPE: "UNSUPPORTED_MEDIA_TYPE",
    FST_ERR_CTP_INVALID_CONTENT_LENGTH: "UNSUPPORTED_MEDIA_TYPE",
};
function registerEventsRoutes(scope, deps) {
    const { pool, verifyAnalyticsToken, now } = deps;
    scope.setErrorHandler((error, request, reply) => {
        request.log.error({ err: error }, "events query failed");
        const statusCode = typeof error.statusCode === "number" && error.statusCode >= 400
            ? error.statusCode
            : 500;
        reply.status(statusCode).send(analyticsErrorBody(statusCode));
    });
    scope.get("/api/analytics/events", async (request, reply) => {
        // ① 解析凭证（fixed5 §4.2 ①/②）：缺失 / 非法 → 401
        const authHeader = request.headers["authorization"];
        const raw = Array.isArray(authHeader) ? authHeader[0] : authHeader;
        const token = (0, query_1.parseAuthorization)(raw);
        if (token === null) {
            return reply.status(401).send(errorBody("UNAUTHORIZED", "unauthorized"));
        }
        // ② 只反查只读分析 token；查询出错 → 500
        let auth;
        try {
            auth = await verifyAnalyticsToken(token);
        }
        catch (err) {
            request.log.error({ err: toError(err) }, "token verification failed");
            return reply
                .status(500)
                .send(errorBody("INTERNAL_ERROR", "internal error"));
        }
        // ③ 可识别但非只读 token（读写 key / webhook Secret / 未知）→ 403
        if (auth === null) {
            return reply.status(403).send(errorBody("FORBIDDEN", "forbidden"));
        }
        // ④ 过期只读 token → 401
        if (auth.expires_at !== null && auth.expires_at <= now()) {
            return reply.status(401).send(errorBody("UNAUTHORIZED", "unauthorized"));
        }
        // ⑤ scope 不足（不含 analytics:read）→ 403
        if (!Array.isArray(auth.scopes) || !auth.scopes.includes("analytics:read")) {
            return reply.status(403).send(errorBody("FORBIDDEN", "forbidden"));
        }
        // ⑥ tenant 只从 token 派生；非法 UUID 是服务端配置错误 → 500
        const tenantId = trustedTenantHeader(request) || auth.tenant_id;
        if (!(0, validate_1.isUuid)(tenantId)) {
            request.log.error({ tenant_id: tenantId }, "token tenant_id is not a UUID");
            return reply
                .status(500)
                .send(errorBody("INTERNAL_ERROR", "internal error"));
        }
        // 参数校验前置：from>to / limit<=0 / since 非法 → 400
        const parsed = (0, query_1.parseEventFilters)(request.query);
        if (!parsed.ok) {
            return reply
                .status(400)
                .send(errorBody("INVALID_QUERY", parsed.message));
        }
        // 查询（SET LOCAL RLS 上下文 + 显式 WHERE 双保险）
        let rows;
        try {
            rows = await (0, query_1.queryEventsScoped)(pool, tenantId, parsed.filters);
        }
        catch (err) {
            request.log.error({ err: toError(err), tenant_id: tenantId }, "query failed");
            return reply
                .status(500)
                .send(errorBody("INTERNAL_ERROR", "internal error"));
        }
        // 多取 1 条判 has_more；裁剪 + 白名单序列化
        const limit = parsed.filters.limit;
        const hasMore = rows.length > limit;
        const page = hasMore ? rows.slice(0, limit) : rows;
        const items = page.map(query_1.serializeEventRow);
        const nextCursor = hasMore ? String(page[page.length - 1].seq) : null;
        return reply.status(200).send({
            items,
            next_cursor: nextCursor,
            has_more: hasMore,
            count: items.length,
        });
    });
}
function registerFunnelRoutes(scope, deps) {
    const { pool, verifyAnalyticsToken, resolveWorkspaceId, sourcePlatformRules, now } = deps;
    scope.setErrorHandler((error, request, reply) => {
        request.log.error({ err: error }, "funnel query failed");
        const statusCode = typeof error.statusCode === "number" && error.statusCode >= 400
            ? error.statusCode
            : 500;
        reply.status(statusCode).send(analyticsErrorBody(statusCode));
    });
    scope.get("/api/analytics/funnel", async (request, reply) => {
        // ① 解析凭证：缺失 / 非法 → 401
        const authHeader = request.headers["authorization"];
        const raw = Array.isArray(authHeader) ? authHeader[0] : authHeader;
        const token = (0, query_1.parseAuthorization)(raw);
        if (token === null) {
            return reply.status(401).send(errorBody("UNAUTHORIZED", "unauthorized"));
        }
        // ② 只反查只读分析 token；查询出错 → 500
        let auth;
        try {
            auth = await verifyAnalyticsToken(token);
        }
        catch (err) {
            request.log.error({ err: toError(err) }, "token verification failed");
            return reply
                .status(500)
                .send(errorBody("INTERNAL_ERROR", "internal error"));
        }
        // ③ 可识别但非只读 token → 403
        if (auth === null) {
            return reply.status(403).send(errorBody("FORBIDDEN", "forbidden"));
        }
        // ④ 过期只读 token → 401
        if (auth.expires_at !== null && auth.expires_at <= now()) {
            return reply.status(401).send(errorBody("UNAUTHORIZED", "unauthorized"));
        }
        // ⑤ scope 不足 → 403
        if (!Array.isArray(auth.scopes) || !auth.scopes.includes("analytics:read")) {
            return reply.status(403).send(errorBody("FORBIDDEN", "forbidden"));
        }
        // ⑥ tenant 只从 token 派生；非法 UUID → 500
        const tenantId = trustedTenantHeader(request) || auth.tenant_id;
        if (!(0, validate_1.isUuid)(tenantId)) {
            request.log.error({ tenant_id: tenantId }, "token tenant_id is not a UUID");
            return reply
                .status(500)
                .send(errorBody("INTERNAL_ERROR", "internal error"));
        }
        // ⑦ 参数校验前置：from>to / granularity / platform / limit / window → 400
        const parsed = (0, funnel_1.parseFunnelParams)(request.query);
        if (!parsed.ok) {
            return reply
                .status(400)
                .send(errorBody("INVALID_QUERY", parsed.message));
        }
        // ⑧ workspace_id 映射（默认恒等，可注入覆盖）
        let workspaceId;
        try {
            workspaceId = await resolveWorkspaceId(tenantId);
        }
        catch (err) {
            request.log.error({ err: toError(err), tenant_id: tenantId }, "resolveWorkspaceId failed");
            return reply
                .status(500)
                .send(errorBody("INTERNAL_ERROR", "internal error"));
        }
        // ⑨ 查询（SET LOCAL RLS 上下文 + 显式 WHERE 双保险）
        let result;
        try {
            result = await (0, funnel_1.queryFunnelScoped)(pool, tenantId, workspaceId, parsed.params, {
                sourcePlatformRules,
            });
        }
        catch (err) {
            request.log.error({ err: toError(err), tenant_id: tenantId }, "query failed");
            return reply
                .status(500)
                .send(errorBody("INTERNAL_ERROR", "internal error"));
        }
        // ⑩ 序列化：bucket 仅在 granularity != total 时出现
        const response = {
            from: result.from,
            to: result.to,
            granularity: parsed.params.granularity,
            platform: parsed.params.platform,
            country: parsed.params.country,
            groups: result.groups.map((r) => (0, funnel_1.serializeFunnelGroup)(r, parsed.params.granularity)),
            roi_by_entity: result.roi.map((r) => (0, funnel_1.serializeRoiEntity)(r, parsed.params.granularity)),
            data_freshness: {
                ...result.freshness,
                generated_at: new Date(now()).toISOString(),
            },
        };
        return reply.status(200).send(response);
    });
}
function registerCollectRoutes(scope, deps) {
    const { resolveEndpoint, enqueue } = deps;
    scope.setErrorHandler((error, request, reply) => {
        request.log.error({ err: error }, "collect request failed");
        const statusCode = typeof error.statusCode === "number" && error.statusCode >= 400
            ? error.statusCode
            : 500;
        const code = FST_ERROR_CODE[error.code] ??
            (statusCode >= 500 ? "INTERNAL_ERROR" : "INVALID_EVENT");
        const message = statusCode >= 500 ? "internal error" : "bad request";
        reply
            .status(statusCode)
            .send(errorBody(code, message, (0, validate_2.tryExtractEventId)(request.body)));
    });
    scope.post("/api/v1/collect/:webhook_id", async (request, reply) => {
        const { webhook_id } = request.params;
        const body = request.body;
        const receivedAt = Date.now();
        // ② 校验三件套 + 白名单 —— 失败 400
        const validated = (0, validate_2.validateEvent)(body);
        if (!validated.ok || !validated.event) {
            return reply
                .status(400)
                .send(errorBody("INVALID_EVENT", "invalid event", (0, validate_2.tryExtractEventId)(body)));
        }
        const { event_id } = validated.event;
        // ③ Secret 鉴权 —— 缺 Secret 401
        const secretHeader = request.headers["x-pt-webhook-secret"];
        const secret = Array.isArray(secretHeader) ? secretHeader[0] : secretHeader;
        if (!secret) {
            return reply
                .status(401)
                .send(errorBody("MISSING_SECRET", "unauthorized", event_id));
        }
        // 端点反查（webhook_id → 端点记录）
        let endpoint = null;
        try {
            endpoint = await resolveEndpoint(webhook_id);
        }
        catch (err) {
            request.log.error({ err: toError(err), webhook_id }, "endpoint lookup failed");
            return reply
                .status(500)
                .send(errorBody("INTERNAL_ERROR", "internal error", event_id));
        }
        // 端点不存在 / 停用 / Secret 错误 → 统一 403，文案一致防探测
        if (!endpoint || endpoint.status !== "active") {
            return reply
                .status(403)
                .send(errorBody("INVALID_SECRET", "unauthorized", event_id));
        }
        if (!(0, collect_server_1.secretMatches)(secret, endpoint.secret_hash)) {
            return reply
                .status(403)
                .send(errorBody("INVALID_SECRET", "unauthorized", event_id));
        }
        // ④ 组装 envelope：tenant_id 由端点反查强制注入，绝不读事件体身份字段
        const envelope = {
            tenant_id: endpoint.tenant_id,
            received_at: receivedAt,
            event: body,
        };
        // ⑤ 入队：入队成功才 200；失败 503 让上游 at-least-once 重试
        let enqueued = false;
        try {
            enqueued = await enqueue(envelope);
        }
        catch (err) {
            request.log.error({ err: toError(err), event_id, tenant_id: endpoint.tenant_id }, "enqueue failed");
            enqueued = false;
        }
        if (!enqueued) {
            return reply
                .status(503)
                .send(errorBody("QUEUE_UNAVAILABLE", "queue unavailable", event_id));
        }
        request.log.info({ event_id, webhook_id, tenant_id: endpoint.tenant_id }, "event accepted");
        // 立即 200，不等待 1.3 落库
        return reply.status(200).send({
            ok: true,
            event_id,
            received_at: receivedAt,
        });
    });
}
// ---------------------------------------------------------------------------
// buildUnifiedServer：组装统一 Fastify 实例
// ---------------------------------------------------------------------------
/**
 * 构建统一服务（一个进程一个端口，四端点齐全）。
 * 每个单元的路由在独立 register 封装作用域内注册，以保留各单元原 setErrorHandler 行为
 * （collect 的 FST 错误码映射与分析端点的 BAD_REQUEST/INTERNAL_ERROR 互不串扰）。
 */
function buildUnifiedServer(options) {
    const { resolveEndpoint, enqueue, verifyAnalyticsToken, pool, loadAuditLogs, loadConfigFindings, resolveWorkspaceId = (tenantId) => tenantId, sourcePlatformRules = attribution_1.DEFAULT_SOURCE_PLATFORM_RULES, now = Date.now, maxBodyBytes = 1024 * 1024, // 1MB，对齐 collect/server.ts
    logger = true, adapter = (0, ingestion_service_1.createIngestionAdapter)({}), } = options;
    const app = (0, fastify_1.default)({ logger, bodyLimit: maxBodyBytes });
    app.register(async scope => {
        require('./ga-connector/routes').registerGaConnectorRoutes(scope, {
            pool, verifyAnalyticsToken, parseAuthorization: query_1.parseAuthorization,
            now, gaConnector: options.gaConnector,
        });
    });
    // 1.4 事件查询
    app.register(async (scope) => {
        registerEventsRoutes(scope, { pool, verifyAnalyticsToken, now });
    });
    // 2.4 漏斗查询
    app.register(async (scope) => {
        registerFunnelRoutes(scope, {
            pool,
            verifyAnalyticsToken,
            resolveWorkspaceId,
            sourcePlatformRules,
            now,
        });
    });
    // 1.5 Token 审计（直接复用 audit/route.ts 已导出的插件，鉴权顺序/错误码逐字一致）
    app.register(route_1.tokenAuditRoutes, {
        verifyAnalyticsToken,
        loadAuditLogs,
        loadConfigFindings,
        now,
    });
    // 1.2 webhook 采集
    app.register(async (scope) => {
        registerCollectRoutes(scope, { resolveEndpoint, enqueue });
    });
    // A9 广告导出导入（业务线；不碰 shell）
    app.register(async (scope) => {
        (0, import_1.registerImportRoutes)(scope, {
            pool,
            verifyAnalyticsToken,
            resolveWorkspaceId,
            parseAuthorization: query_1.parseAuthorization,
        });
    });
    // A18 事件 CSV 批量导入（A16 状态机 + A17 适配；不改 collect/）
    app.register(async (scope) => {
        (0, event_import_1.registerEventImportRoutes)(scope, {
            pool,
            verifyAnalyticsToken,
            resolveWorkspaceId,
            parseAuthorization: query_1.parseAuthorization,
        });
    });
    // A17 事件接入适配层（映射 / 适配 / 连接测试 / 质量统计；不改 collect/）
    app.register(async (scope) => {
        (0, ingestion_1.registerIngestionAdapterRoutes)(scope, {
            verifyAnalyticsToken,
            resolveWorkspaceId,
            parseAuthorization: query_1.parseAuthorization,
            adapter,
        });
    });
    // B12 SS-GTM 原始事件接入（webhook secret 鉴权 → A17 适配 → collect 三件套 → 入队；不改 collect/）
    app.register(async (scope) => {
        (0, raw_ingest_1.registerRawIngestRoutes)(scope, {
            resolveEndpoint,
            secretMatches: collect_server_1.secretMatches,
            resolveWorkspaceId,
            enqueue,
            adapter,
        });
    });
    // A19 归因结果 REST（包装 workflows/engine；保留旧 /api/analytics/funnel）
    app.register(async (scope) => {
        (0, attribution_api_1.registerAttributionApiRoutes)(scope, {
            pool,
            verifyAnalyticsToken,
            resolveWorkspaceId,
            parseAuthorization: query_1.parseAuthorization,
            now,
            sourcePlatformRules,
        });
    });

    // B14：内部接口 —— 为租户签发分析 token（仅限 127.0.0.1 + X-Internal-Key）
    app.post("/internal/tenant-token", async (request, reply) => {
        // IP 限制：仅 127.0.0.1
        const clientIp = request.ip || request.socket?.remoteAddress;
        if (clientIp !== "127.0.0.1" && clientIp !== "::1") {
            reply.code(403).send({ ok: false, error: "Forbidden: internal endpoint" });
            return;
        }
        // 密钥验证：X-Internal-Key 必须匹配 PT_DASH_INTERNAL_KEY
        const internalKeyHeader = request.headers["x-internal-key"];
        if (internalKeyHeader !== options.internalKey) {
            reply.code(403).send({ ok: false, error: "Invalid internal key" });
            return;
        }
        // 请求体验证
        const body = request.body;
        if (!body || typeof body.tenant_id !== "string" || typeof body.label !== "string") {
            reply.code(400).send({ ok: false, error: "Bad request: {tenant_id:string, label:string}" });
            return;
        }
        // 生成确定性 token
        const { generateTenantAnalyticsToken } = require("../lib/deps.cjs");
        const token = generateTenantAnalyticsToken(options.internalKey, body.tenant_id);
        // 插入 analytics_tokens 表（只存 hash）
        const { insertAnalyticsToken } = require("../lib/deps.cjs");
        await insertAnalyticsToken(pool, body.tenant_id, token, body.label, ["analytics:read"]);
        // B14：同时建立租户 ↔ 工作区映射（一租户一工作区：ws_<tenantId>），
        // 否则新租户打 /api/business/* 会 403 NO_WORKSPACE
        await pool.query(
            `INSERT INTO tenant_workspaces (tenant_id, workspace_id, label)
             VALUES ($1::uuid,$2,$3) ON CONFLICT (tenant_id) DO NOTHING`,
            [body.tenant_id, "ws_" + body.tenant_id, body.label]
        );
        // 返回成功（实际 shell 不需要 token 明文，但返回便于调试）
        reply.send({ ok: true, token });
    });

    return app;
}
/** 构建并监听，返回已启动的服务与关闭句柄。 */
async function startUnifiedServer(options) {
    const app = buildUnifiedServer(options);
    const host = options.host ?? "0.0.0.0";
    const port = options.port ?? Number(process.env.PORT ?? 3000);
    await app.listen({ port, host });
    return {
        app,
        address: `${host}:${port}`,
        close: () => app.close(),
    };
}
//# sourceMappingURL=server.js.map
