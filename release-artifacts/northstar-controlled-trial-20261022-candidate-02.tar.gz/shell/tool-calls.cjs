"use strict";
/**
 * tool-calls.cjs —— 工具调用日志（M1）
 * ============================================================================
 * 只做 tool_calls 表的读写，不做身份 / 会话 / 权限判断，避免越界。
 *
 * 对外接口（server.cjs 会调）：
 *   const tc = await initToolCalls(db);
 *   const { id } = await tc.start({ tenantId, workspaceId, userId, toolName, inputSummary });
 *   await tc.finish(id, { outputSummary, durationMs, tokenCount, status });
 *   const rows = await tc.list({ tenantId, workspaceId, range }); // range=today|week|month
 *
 * 隔离红线：list() 永远带 workspace_id + tenant_id 过滤，绝不提供跨 workspace 读取。
 * ============================================================================
 */

// range → SQL 时间下界（滚动窗口：today=当天零点起，week=近 7 天，month=近 30 天）。
function rangeLowerBound(range) {
  switch (String(range || "")) {
    case "today":
      return "date_trunc('day', now())";
    case "week":
      return "date_trunc('day', now()) - interval '7 days'";
    case "month":
    default:
      return "date_trunc('day', now()) - interval '30 days'";
  }
}

const toIso = (v) => (v instanceof Date ? v.toISOString() : (v == null ? null : String(v)));
const strOrNull = (v) => (v == null ? null : String(v));
function tokenValue(value) {
  if (value == null || value === "") return null;
  const number = typeof value === "number" ? value : Number(value);
  if (!Number.isSafeInteger(number) || number < 0) return null;
  return number;
}
function evidenceUsage(value) {
  const raw = value && typeof value === "object" ? value : {};
  const pick = (camel, snake) => tokenValue(raw[camel] ?? raw[snake]);
  const inputTokens = pick("inputTokens", "input_tokens");
  const outputTokens = pick("outputTokens", "output_tokens");
  const cacheReadTokens = pick("cacheReadTokens", "cache_read_tokens");
  const cacheWriteTokens = pick("cacheWriteTokens", "cache_write_tokens");
  const providedTotal = pick("totalTokens", "total_tokens");
  const totalTokens = providedTotal ?? (inputTokens != null && outputTokens != null
    ? tokenValue(inputTokens + outputTokens) : null);
  const known = [inputTokens, outputTokens, cacheReadTokens, cacheWriteTokens].some((item) => item != null);
  const coverage = inputTokens != null && outputTokens != null ? "complete" : (known ? "partial" : "unknown");
  return { inputTokens, outputTokens, cacheReadTokens, cacheWriteTokens, totalTokens, coverage };
}

async function initToolCalls(db) {
  if (!db) throw new Error("initToolCalls 需要 db（PGlite 实例）");

  /** 执行前落库一条 started，返回自增 id（供 finish 回写）。 */
  async function start(entry) {
    const r = await db.query(
      `INSERT INTO tool_calls (tenant_id, workspace_id, user_id, tool_name, input_summary, category, model_name, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, 'started')
       RETURNING id`,
      [entry.tenantId, entry.workspaceId, entry.userId, entry.toolName, strOrNull(entry.inputSummary),
       strOrNull(entry.category), strOrNull(entry.modelName)]
    );
    return { id: r.rows[0].id };
  }

  /** 执行后回写同一条记录：补输出摘要 / 耗时 / token / 终态 / 模型名（media 类工具执行后才知模型）。 */
  async function finish(id, entry) {
    await db.query(
      `UPDATE tool_calls
          SET output_summary = $2, duration_ms = $3, token_count = $4, status = $5,
              model_name = COALESCE($6, model_name)
        WHERE id = $1`,
      [id, strOrNull(entry.outputSummary), entry.durationMs == null ? null : Number(entry.durationMs),
       entry.tokenCount == null ? null : Number(entry.tokenCount), entry.status || "completed",
       strOrNull(entry.modelName)]
    );
  }

  /** 查当前 workspace 自己的调用日志（安全红线：恒按 workspace + tenant 过滤）。 */
  async function list({ tenantId, workspaceId, range }) {
    const bound = rangeLowerBound(range);
    const r = await db.query(
      `SELECT id, "timestamp", tenant_id, workspace_id, user_id, tool_name,
              input_summary, output_summary, duration_ms, token_count, status,
              category, model_name
         FROM tool_calls
        WHERE workspace_id = $1 AND tenant_id = $2 AND "timestamp" >= ` + bound + `
        ORDER BY "timestamp" DESC`,
      [workspaceId, tenantId]
    );
    return r.rows.map((row) => ({
      id: row.id,
      timestamp: toIso(row.timestamp),
      tenantId: row.tenant_id,
      workspaceId: row.workspace_id,
      userId: row.user_id,
      toolName: row.tool_name,
      inputSummary: row.input_summary,
      outputSummary: row.output_summary,
      durationMs: row.duration_ms,
      tokenCount: row.token_count,
      status: row.status,
      category: row.category,
      modelName: row.model_name,
    }));
  }

  /** 主对话轮次 token 用量：落一条 chat_usage（与 tool_calls 子工具调用分开）。 */
  async function logUsage(entry) {
    const evidence = entry && entry.usageEvidence;
    if (evidence != null) {
      if (!evidence || typeof evidence !== "object" || !Array.isArray(evidence.responses)) {
        throw Object.assign(new TypeError("usageEvidence.responses must be an array"), { code: "USAGE_EVIDENCE_INVALID" });
      }
      const seen = new Set();
      const rows = evidence.responses.map((response) => {
        const responseSeq = response && response.responseSeq;
        if (!Number.isSafeInteger(responseSeq) || responseSeq < 0 || seen.has(responseSeq)) {
          throw Object.assign(new TypeError("usageEvidence responseSeq must be unique non-negative integers"), { code: "USAGE_EVIDENCE_INVALID" });
        }
        seen.add(responseSeq);
        return { responseSeq, usage: evidenceUsage(response.usage) };
      });
      if (!rows.length) return { inserted: 0, duplicate: 0, observedResponses: 0 };
      if (entry.runId != null && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(entry.runId))) {
        throw Object.assign(new TypeError("runId must be a UUID"), { code: "USAGE_EVIDENCE_INVALID" });
      }
      return db.transaction(async (tx) => {
        if (entry.runId != null) {
          const owner = await tx.query("SELECT 1 FROM agent_runs WHERE run_id=$1 AND user_id=$2 AND tenant_id=$3 AND workspace_id=$4", [entry.runId, entry.userId, entry.tenantId, entry.workspaceId]);
          if (!owner.rows.length) throw Object.assign(new Error("Run usage identity does not match its owner"), { code: "RUN_USAGE_IDENTITY_MISMATCH" });
        }
        let inserted = 0;
        for (const row of rows) {
          const usage = row.usage;
          const result = entry.runId == null
            ? await tx.query(
                `INSERT INTO chat_usage (tenant_id,workspace_id,user_id,model,prompt_tokens,completion_tokens,total_tokens,run_id,response_seq,cache_read_tokens,cache_write_tokens,coverage)
                 VALUES ($1,$2,$3,$4,$5,$6,$7,NULL,$8,$9,$10,$11) RETURNING id`,
                [entry.tenantId, entry.workspaceId, entry.userId, strOrNull(entry.model), usage.inputTokens, usage.outputTokens, usage.totalTokens, row.responseSeq, usage.cacheReadTokens, usage.cacheWriteTokens, usage.coverage],
              )
            : await tx.query(
                `INSERT INTO chat_usage (tenant_id,workspace_id,user_id,model,prompt_tokens,completion_tokens,total_tokens,run_id,response_seq,cache_read_tokens,cache_write_tokens,coverage)
                 SELECT $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12
                   FROM agent_runs r WHERE r.run_id=$8 AND r.user_id=$3 AND r.tenant_id=$1 AND r.workspace_id=$2
                 ON CONFLICT DO NOTHING RETURNING id`,
                [entry.tenantId, entry.workspaceId, entry.userId, strOrNull(entry.model), usage.inputTokens, usage.outputTokens, usage.totalTokens, entry.runId, row.responseSeq, usage.cacheReadTokens, usage.cacheWriteTokens, usage.coverage],
              );
          if (result.rows.length) {
            inserted++;
          } else {
            const existing = (await tx.query(
              `SELECT tenant_id,workspace_id,user_id,model,prompt_tokens,completion_tokens,total_tokens,cache_read_tokens,cache_write_tokens,coverage
                 FROM chat_usage WHERE run_id=$1 AND response_seq=$2 FOR UPDATE`,
              [entry.runId, row.responseSeq],
            )).rows[0];
            const sameNumber = (left, right) => left == null ? right == null : right != null && Number(left) === Number(right);
            const sameText = (left, right) => left == null ? right == null : String(left) === String(right);
            const isSameEvidence = existing
              && String(existing.tenant_id).toLowerCase() === String(entry.tenantId).toLowerCase()
              && String(existing.user_id).toLowerCase() === String(entry.userId).toLowerCase()
              && String(existing.workspace_id) === String(entry.workspaceId)
              && sameText(existing.model, strOrNull(entry.model))
              && sameNumber(existing.prompt_tokens, usage.inputTokens)
              && sameNumber(existing.completion_tokens, usage.outputTokens)
              && sameNumber(existing.total_tokens, usage.totalTokens)
              && sameNumber(existing.cache_read_tokens, usage.cacheReadTokens)
              && sameNumber(existing.cache_write_tokens, usage.cacheWriteTokens)
              && existing.coverage === usage.coverage;
            if (!isSameEvidence) {
              throw Object.assign(new Error("Conflicting usage evidence for Run response sequence"), { code: "USAGE_EVIDENCE_CONFLICT" });
            }
          }
        }
        return { inserted, duplicate: rows.length - inserted, observedResponses: rows.length };
      });
    }
    // Backward-compatible legacy entry: callers without response evidence may
    // still write one row, but absent/invalid token values stay NULL.
    const legacy = entry.usage && typeof entry.usage === "object" ? entry.usage : entry;
    const usage = evidenceUsage({
      inputTokens: legacy.inputTokens ?? entry.inputTokens ?? entry.promptTokens ?? legacy.prompt_tokens,
      outputTokens: legacy.outputTokens ?? entry.outputTokens ?? entry.completionTokens ?? legacy.completion_tokens,
      cacheReadTokens: legacy.cacheReadTokens ?? legacy.cache_read_tokens,
      cacheWriteTokens: legacy.cacheWriteTokens ?? legacy.cache_write_tokens,
      totalTokens: legacy.totalTokens ?? entry.totalTokens ?? legacy.total_tokens,
    });
    await db.query(
      `INSERT INTO chat_usage (tenant_id, workspace_id, user_id, model, prompt_tokens, completion_tokens, total_tokens, coverage)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [entry.tenantId, entry.workspaceId, entry.userId, strOrNull(entry.model), usage.inputTokens, usage.outputTokens, usage.totalTokens, usage.coverage]
    );
    return { inserted: 1, duplicate: 0, observedResponses: 1 };
  }

  /** 用量聚合：今日 / 本月 / 按模型（模型分布按所选 range）。 */
  async function usageSummary({ tenantId, workspaceId, range }) {
    const todayBound = "date_trunc('day', now())";
    const monthBound = "date_trunc('month', now())";
    const rangeBound = rangeLowerBound(range);

    const [today, month, byModel] = await Promise.all([
      db.query(
        `SELECT COUNT(*) AS count,
                CASE WHEN COUNT(*)=COUNT(prompt_tokens) THEN SUM(prompt_tokens) END AS prompt_tokens,
                CASE WHEN COUNT(*)=COUNT(completion_tokens) THEN SUM(completion_tokens) END AS completion_tokens,
                CASE WHEN COUNT(*)=COUNT(total_tokens) THEN SUM(total_tokens) END AS total_tokens,
                CASE WHEN COUNT(*)>0 AND BOOL_AND(coverage='complete') THEN 'complete' WHEN COUNT(*)=0 THEN 'unavailable' WHEN BOOL_OR(coverage<>'unknown') THEN 'partial' ELSE 'unknown' END AS coverage
           FROM chat_usage
          WHERE workspace_id = $1 AND tenant_id = $2 AND "timestamp" >= ` + todayBound,
        [workspaceId, tenantId]
      ),
      db.query(
        `SELECT COUNT(*) AS count,
                CASE WHEN COUNT(*)=COUNT(prompt_tokens) THEN SUM(prompt_tokens) END AS prompt_tokens,
                CASE WHEN COUNT(*)=COUNT(completion_tokens) THEN SUM(completion_tokens) END AS completion_tokens,
                CASE WHEN COUNT(*)=COUNT(total_tokens) THEN SUM(total_tokens) END AS total_tokens,
                CASE WHEN COUNT(*)>0 AND BOOL_AND(coverage='complete') THEN 'complete' WHEN COUNT(*)=0 THEN 'unavailable' WHEN BOOL_OR(coverage<>'unknown') THEN 'partial' ELSE 'unknown' END AS coverage
           FROM chat_usage
          WHERE workspace_id = $1 AND tenant_id = $2 AND "timestamp" >= ` + monthBound,
        [workspaceId, tenantId]
      ),
      db.query(
        `SELECT COALESCE(model, '未标注') AS model,
                COUNT(*) AS calls,
                CASE WHEN COUNT(*)=COUNT(prompt_tokens) THEN SUM(prompt_tokens) END AS prompt_tokens,
                CASE WHEN COUNT(*)=COUNT(completion_tokens) THEN SUM(completion_tokens) END AS completion_tokens,
                CASE WHEN COUNT(*)=COUNT(total_tokens) THEN SUM(total_tokens) END AS total_tokens,
                CASE WHEN BOOL_AND(coverage='complete') THEN 'complete' WHEN BOOL_OR(coverage<>'unknown') THEN 'partial' ELSE 'unknown' END AS coverage
           FROM chat_usage
          WHERE workspace_id = $1 AND tenant_id = $2 AND "timestamp" >= ` + rangeBound + `
          GROUP BY model
          ORDER BY total_tokens DESC NULLS LAST`,
        [workspaceId, tenantId]
      ),
    ]);

    const numericOrNull = (value) => value == null ? null : Number(value);
    const pick = (row) => row && row.rows && row.rows[0]
      ? {
          promptTokens: numericOrNull(row.rows[0].prompt_tokens),
          completionTokens: numericOrNull(row.rows[0].completion_tokens),
          totalTokens: numericOrNull(row.rows[0].total_tokens),
          count: Number(row.rows[0].count) || 0,
          coverage: row.rows[0].coverage || "unknown",
          cost: null,
          costCoverage: "unknown",
        }
      : { promptTokens: null, completionTokens: null, totalTokens: null, count: 0, coverage: "unavailable", cost: null, costCoverage: "unknown" };

    return {
      today: pick(today),
      month: pick(month),
      byModel: (byModel.rows || []).map((row) => ({
        model: row.model,
        calls: Number(row.calls) || 0,
        promptTokens: numericOrNull(row.prompt_tokens),
        completionTokens: numericOrNull(row.completion_tokens),
        totalTokens: numericOrNull(row.total_tokens),
        coverage: row.coverage || "unknown",
        cost: null,
        costCoverage: "unknown",
      })),
    };
  }

  return { start, finish, list, logUsage, usageSummary };
}

module.exports = { initToolCalls };
