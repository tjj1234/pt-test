"use strict";

const TOKEN_FIELDS = Object.freeze(["inputTokens", "outputTokens", "cacheReadTokens", "cacheWriteTokens"]);
const token = (value) => Number.isSafeInteger(value) && value >= 0 ? value : null;

// Counts observed SDK response events, not network attempts or internal retries.
// Missing evidence remains unknown; it must never become a zero-cost response.
function collectResponseUsage(events, firstSeq = 0) {
  if (!Number.isSafeInteger(firstSeq) || firstSeq < 0) throw new TypeError("A valid response cursor is required");
  const seen = new Set();
  const responses = [];
  let started = !(events || []).some((event) => event?.type === "turn/start" && event.seq >= firstSeq);
  for (const event of events || []) {
    if (event?.seq >= firstSeq && event.type === "turn/start") { started = true; continue; }
    if (!started) continue;
    if (event?.type !== "assistant/message" || !Number.isSafeInteger(event.seq) || event.seq < firstSeq || seen.has(event.seq)) continue;
    seen.add(event.seq);
    const raw = event.data?.usage;
    responses.push({ responseSeq: event.seq, usage: Object.fromEntries(TOKEN_FIELDS.map((key) => [key, token(raw?.[key])])) });
  }
  if (!responses.length) return { usage: null, observedResponses: 0, responses: [], coverage: "unavailable" };
  const usage = {};
  for (const key of TOKEN_FIELDS) {
    const values = responses.map((response) => response.usage[key]);
    const total = values.every((value) => value !== null) ? values.reduce((sum, value) => sum + value, 0) : null;
    usage[key] = Number.isSafeInteger(total) ? total : null;
  }
  usage.totalTokens = usage.inputTokens !== null && usage.outputTokens !== null && Number.isSafeInteger(usage.inputTokens + usage.outputTokens)
    ? usage.inputTokens + usage.outputTokens : null;
  return { usage, observedResponses: responses.length, responses,
    coverage: responses.every((response) => response.usage.inputTokens !== null && response.usage.outputTokens !== null) ? "complete" : "partial" };
}

module.exports = { collectResponseUsage, TOKEN_FIELDS };
