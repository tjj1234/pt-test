'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');

function text(value) { return typeof value === 'string' && value.trim() ? value.trim() : ''; }
function hash(value) { return createHash('sha256').update(String(value), 'utf8').digest('hex'); }

/** Stable, non-secret cache scope. The credential itself is never written to disk. */
function resolveScopeId({ apiKey, baseURL, scopeId } = {}) {
  const key = text(apiKey);
  if (!key) return null;
  const base = text(baseURL).replace(/\/+$/, '');
  const explicit = text(scopeId);
  return 'pt-scope-' + hash(JSON.stringify([base, explicit, hash(key)]));
}

function cacheFile(root, scopeId) {
  if (!text(scopeId)) throw new TypeError('scopeId required');
  return path.join(root, 'model-catalog-' + hash(scopeId) + '.json');
}

function readScopedCache(root, scopeId) {
  try {
    const file = cacheFile(root, scopeId);
    const value = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (value?.schemaVersion !== 1 || value.scopeId !== scopeId || !value.snapshot || value.snapshot.scopeId !== scopeId || !Array.isArray(value.snapshot.models)) return null;
    return value.snapshot;
  } catch { return null; }
}

function writeScopedCache(root, scopeId, snapshot) {
  if (!text(scopeId) || snapshot?.scopeId !== scopeId || !Array.isArray(snapshot.models)) return false;
  const file = cacheFile(root, scopeId);
  const temporary = file + '.' + process.pid + '.' + Math.random().toString(16).slice(2) + '.tmp';
  try {
    fs.mkdirSync(root, { recursive: true });
    fs.writeFileSync(temporary, JSON.stringify({ schemaVersion: 1, scopeId, snapshot }), { mode: 0o600 });
    fs.renameSync(temporary, file);
    return true;
  } catch {
    try { fs.unlinkSync(temporary); } catch { /* best-effort temp cleanup */ }
    return false;
  }
}

module.exports = { resolveScopeId, cacheFile, readScopedCache, writeScopedCache };
