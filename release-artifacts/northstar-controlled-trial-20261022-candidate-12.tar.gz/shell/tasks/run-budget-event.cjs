"use strict";

const LIMIT_KEYS = Object.freeze([
  "maxDurationMs",
  "maxModelCalls",
  "maxToolCalls",
  "maxToolCallsPerKey",
  "maxRetries",
  "maxOutputTokens",
]);
const ZERO_ALLOWED = new Set(["maxToolCalls", "maxToolCallsPerKey", "maxRetries"]);
const STATUS_VALUES = Object.freeze({
  costStatus: new Set(["unlimited", "unknown", "known"]),
  policyStatus: new Set(["configured", "unconfigured"]),
  clockStatus: new Set(["monotonic", "unknown"]),
});

function buildRunBudgetUsage(source) {
  const input = source && typeof source === "object" ? source : {};
  const raw = input.snapshot && typeof input.snapshot === "object" ? input.snapshot : {};
  const snapshot = {
    elapsedMs: Number.isFinite(raw.elapsedMs) ? raw.elapsedMs : null,
    modelCalls: Number.isSafeInteger(raw.modelCalls) ? raw.modelCalls : 0,
    toolCalls: Number.isSafeInteger(raw.toolCalls) ? raw.toolCalls : 0,
    retries: Number.isSafeInteger(raw.retries) ? raw.retries : 0,
    duplicateToolCalls: Number.isSafeInteger(raw.duplicateToolCalls) ? raw.duplicateToolCalls : 0,
    costStatus: STATUS_VALUES.costStatus.has(raw.costStatus) ? raw.costStatus : "unknown",
    policyStatus: STATUS_VALUES.policyStatus.has(raw.policyStatus) ? raw.policyStatus : (input.configured === true ? "configured" : "unconfigured"),
    clockStatus: STATUS_VALUES.clockStatus.has(raw.clockStatus) ? raw.clockStatus : "unknown",
  };
  const rawLimits = input.limits && typeof input.limits === "object" ? input.limits : {};
  const limits = Object.fromEntries(LIMIT_KEYS.filter((key) => {
    const value = rawLimits[key];
    return Number.isSafeInteger(value) && (ZERO_ALLOWED.has(key) ? value >= 0 : value > 0);
  }).map((key) => [key, rawLimits[key]]));
  const configured = input.configured === true;
  return { kind: "run_budget", configured, status: configured ? "configured" : "unconfigured", limits, snapshot };
}

module.exports = { buildRunBudgetUsage };
